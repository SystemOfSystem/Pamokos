let numbers = [ 1, -3, 5, -3 ,0]


let positives = (numbers) => numbers.getElementByValue(()numbers > 0);